import math 

def area(base, height):
    return 0.5 * base * height 

def perimeter(side1, side2, side3):
    return side1 + side2 + side3