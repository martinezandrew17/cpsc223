def add(a,b):
    return a + b # Addition

def sub(a,b):
    return a - b # Subtraction 

def multiply(a, b):
    return a * b # Multiplication

def divide(a,b):
    if b == 0:
        return None
    return a / b # Division
