#!/bin/bash
python -m unittest -v test